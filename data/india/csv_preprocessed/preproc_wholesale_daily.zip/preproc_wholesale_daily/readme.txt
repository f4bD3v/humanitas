the dataset includes the following 7 products:
'Rice','Wheat','Banana', 'Apple','Coriander','Potato', 'Onion'

The NaN cutoff rate is 0.4, meaning that only series with more than 60% of
valid data will be included.
