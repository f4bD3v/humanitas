from Orange.core import \
            kNNLearner, \
            FindNearest_BruteForce as FindNearest, \
            FindNearestConstructor_BruteForce as FindNearestConstructor, \
            kNNClassifier, \
            P2NN
            #FindNearest
            #FindNearestConstructor
