from Orange import core

MajorityLearner = core.MajorityLearner
