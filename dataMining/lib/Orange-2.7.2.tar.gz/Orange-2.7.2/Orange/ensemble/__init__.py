__all__ = ["bagging", "boosting", "forest", "stacking"]
__docformat__ = 'restructuredtext'
