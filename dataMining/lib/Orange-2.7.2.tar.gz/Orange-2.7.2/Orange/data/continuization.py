"""
###################################
Continuization (``continuization``)
###################################
"""

from Orange.core import DomainContinuizer
