from orange import \
     MakeRandomIndices as SubsetIndices, \
     MakeRandomIndicesN as SubsetIndicesN, \
     MakeRandomIndicesCV as SubsetIndicesCV, \
     MakeRandomIndicesMultiple as SubsetIndicesMultiple, \
     MakeRandomIndices2 as SubsetIndices2
