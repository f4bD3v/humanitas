"""
.. autoclass:: Table
"""
from Orange import core

Table = core.ExampleTable
Instance = core.Example
Value = core.Value
StringValue = core.StringValue
Domain = core.Domain