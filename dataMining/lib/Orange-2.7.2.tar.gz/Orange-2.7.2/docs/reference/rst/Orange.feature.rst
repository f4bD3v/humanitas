#####################
Feature (``feature``)
#####################

.. automodule:: Orange.feature

.. toctree::
   :maxdepth: 2

   Orange.feature.descriptor
   Orange.feature.scoring
   Orange.feature.selection
   Orange.feature.discretization
   Orange.feature.continuization
   Orange.feature.imputation
