.. automodule:: Orange.regression.tree
