.. automodule:: Orange.projection.som
