.. automodule:: Orange.clustering.hierarchical
