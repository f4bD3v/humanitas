.. automodule:: Orange.clustering.consensus
