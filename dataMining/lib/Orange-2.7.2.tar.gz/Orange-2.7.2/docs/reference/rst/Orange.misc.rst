########################
Miscellaneous (``misc``)
########################

.. automodule:: Orange.misc
