.. automodule:: Orange.classification.neural
