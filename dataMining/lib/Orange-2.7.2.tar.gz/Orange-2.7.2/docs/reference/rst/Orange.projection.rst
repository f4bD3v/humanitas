#############################
Projections (``projection``)
#############################

.. toctree::
   :maxdepth: 2

   Orange.projection.linear
   Orange.projection.mds
   Orange.projection.som
   Orange.projection.correspondence

