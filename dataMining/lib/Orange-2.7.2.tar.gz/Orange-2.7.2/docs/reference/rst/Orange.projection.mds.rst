.. automodule:: Orange.projection.mds
