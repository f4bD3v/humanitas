======================
Feature Continuization
======================

Orange currently provides no easy-to-use methods for continuization of
individual features. Documentation for
:doc:`Continuization of data <Orange.data.continuization>` describes how
to continuize entire data tables.