###############################
Developer utilities (``utils``)
###############################

.. automodule:: Orange.utils
