===========================
Data description (``data``)
===========================

.. toctree::

    Orange.data.table
    Orange.data.domain
    Orange.data.instance
    Orange.data.value
    Orange.data.formats
    Orange.data.sample
    Orange.data.filter
    Orange.data.discretization
    Orange.data.continuization
    Orange.data.imputation
    Orange.data.preprocess
    Orange.data.utils
    Orange.data.sql
    Orange.data.outliers
