========
Overview
========

.. currentmodule:: Orange.OrangeCanvas

Orange canvas is build around the a scheme (workflow) model, which is
implmented in the :mod:`~Orange.OrangeCanvas.scheme` package. The
:mod:`~Orange.OrangeCanvas.registry` package handles the discovery of
available/installed widgets. Common reusable gui elements used
for building the user interface reside in th :mod:`~Orange.OrangeCanvas.gui`
package.
