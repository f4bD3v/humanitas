=============================
Tool Box Widget (``toolbox``)
=============================

.. automodule:: Orange.OrangeCanvas.gui.toolbox

.. autoclass:: Orange.OrangeCanvas.gui.toolbox.ToolBox
   :members:
   :member-order: bysource
   :show-inheritance:

   .. autoattribute:: tabToogled(index, state)

      Signal emitted when a tab at `index` is toggled.