=============================================
Frameless Window Widget (``framelesswindow``)
=============================================

.. automodule:: Orange.OrangeCanvas.gui.framelesswindow

.. autoclass:: Orange.OrangeCanvas.gui.framelesswindow.FramelessWindow
   :members:
   :member-order: bysource
   :show-inheritance: