==================================
Collapsible Dock Widget (``dock``)
==================================

.. automodule:: Orange.OrangeCanvas.gui.dock

.. autoclass:: Orange.OrangeCanvas.gui.dock.CollapsibleDockWidget
   :members:
   :member-order: bysource
   :show-inheritance: