.. gui:

######################
GUI elements (``gui``)
######################

.. automodule:: Orange.OrangeCanvas.gui

.. toctree::
   :maxdepth: 1

   gui.dock
   gui.dropshadow
   gui.framelesswindow
   gui.lineedit
   gui.quickhelp
   gui.splashscreen
   gui.stackedwidget
   gui.toolbar
   gui.toolbox
   gui.toolgrid
   gui.tooltree
