======================
Tool Bar (``toolbar``)
======================

.. automodule:: Orange.OrangeCanvas.gui.toolbar

.. autoclass:: Orange.OrangeCanvas.gui.toolbar.DynamicResizeToolBar
   :members:
   :member-order: bysource
   :show-inheritance:
