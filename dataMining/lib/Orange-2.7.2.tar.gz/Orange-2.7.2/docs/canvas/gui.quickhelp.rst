==========================
Quick Help (``quickhelp``)
==========================

.. automodule:: Orange.OrangeCanvas.gui.quickhelp

.. autoclass:: Orange.OrangeCanvas.gui.quickhelp.QuickHelp
   :members:
   :member-order: bysource
   :show-inheritance:
