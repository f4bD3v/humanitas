.. scheme:

###################
Scheme (``scheme``)
###################


.. automodule:: Orange.OrangeCanvas.scheme


.. toctree::

   scheme.scheme
   scheme.node
   scheme.link
   scheme.annotation
   scheme.readwrite
