.. schemereadwrite:

====================================
Scheme Serialization (``readwrite``)
====================================


.. automodule:: Orange.OrangeCanvas.scheme.readwrite
   :members: