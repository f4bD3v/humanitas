================================
Splash Screen (``splashscreen``)
================================

.. automodule:: Orange.OrangeCanvas.gui.splashscreen

.. autoclass:: Orange.OrangeCanvas.gui.splashscreen.SplashScreen
   :members:
   :member-order: bysource
   :show-inheritance:
