==================================
Drop Shadow Frame (``dropshadow``)
==================================

.. automodule:: Orange.OrangeCanvas.gui.dropshadow

.. autoclass:: Orange.OrangeCanvas.gui.dropshadow.DropShadowFrame
   :members:
   :member-order: bysource
   :show-inheritance: