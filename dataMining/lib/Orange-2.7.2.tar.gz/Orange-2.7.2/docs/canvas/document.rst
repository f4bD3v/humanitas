=======================
Document (``document``)
=======================

.. automodule:: Orange.OrangeCanvas.document


.. toctree::

   document.schemeedit
   document.quickmenu