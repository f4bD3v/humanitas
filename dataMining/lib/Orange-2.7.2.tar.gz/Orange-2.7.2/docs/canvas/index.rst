#######################
Orange Canvas Reference
#######################

The Orange Canvas API reference

.. toctree::

   gui
   scheme
   registry
   canvas
   document
