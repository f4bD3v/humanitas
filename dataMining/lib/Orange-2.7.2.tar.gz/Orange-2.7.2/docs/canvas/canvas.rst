===================
Canvas (``canvas``)
===================


.. automodule:: Orange.OrangeCanvas.canvas


.. toctree::

   canvas.scene
   canvas.items.nodeitem
   canvas.items.linkitem
   canvas.items.annotationitem
