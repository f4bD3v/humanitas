.. canvas-link-item:

========================
Link Item (``linkitem``)
========================

.. automodule:: Orange.OrangeCanvas.canvas.items.linkitem


.. autoclass:: LinkItem
   :members:
   :member-order: bysource
   :show-inheritance:
