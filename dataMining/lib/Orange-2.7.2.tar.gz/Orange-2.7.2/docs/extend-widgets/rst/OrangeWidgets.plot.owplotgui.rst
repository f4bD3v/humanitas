.. automodule :: OrangeWidgets.plot.owplotgui
