====================================
Plot tools (``plot``)
====================================

.. automodule:: plot

.. toctree:: 
   :maxdepth: 1

   OrangeWidgets.plot.owplot
   OrangeWidgets.plot.owplotgui
   OrangeWidgets.plot.owtools
   OrangeWidgets.plot.owcurve
   OrangeWidgets.plot.owpoint
   OrangeWidgets.plot.owlegend
..   OrangeWidgets.plot.owaxis TODO: add file
