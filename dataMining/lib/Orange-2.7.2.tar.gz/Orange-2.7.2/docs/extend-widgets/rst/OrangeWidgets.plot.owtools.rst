.. automodule :: OrangeWidgets.plot.owtools
