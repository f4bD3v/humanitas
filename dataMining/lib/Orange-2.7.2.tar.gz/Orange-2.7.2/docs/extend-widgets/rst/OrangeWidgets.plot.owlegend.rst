.. automodule :: OrangeWidgets.plot.owlegend
