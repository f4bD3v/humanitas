.. automodule :: OrangeWidgets.plot.owpoint
