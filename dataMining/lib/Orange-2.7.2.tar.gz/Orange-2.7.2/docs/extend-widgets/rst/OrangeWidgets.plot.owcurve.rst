.. automodule :: Orange.OrangeWidgets.plot.owcurve
